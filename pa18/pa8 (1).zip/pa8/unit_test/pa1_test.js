/* This file is for testing quick.js (we won't test extra.js) 
 * it may help to revisit your initial pa1 submission         */

const { List } = require('immutable')

const test_fold_left = (fold_left) => {
    // TODO: Add tests for fold_left

    // Return false if this implementation is incorrect
    return false;
}

const test_map = (map) => {
    // TODO: Add tests for map

    // Return false if this implementation is incorrect
    return false;
}


const test_filter = (filter) => {
    // TODO: Add tests for filter

    // Return false if this implementation is incorrect
    return false;
}


const test_partition = (partition) => {
    // TODO: Add tests for partition

    // Return false if this implementation is incorrect
    return false;
}


const test_quicksort = (quicksort) => {
    // TODO: Add tests for quicksort

    // Return false if this implementation is incorrect
    return false;
}


/* DO NOT MODIFY BELOW THIS LINE */
exports.test_fold_left = test_fold_left;
exports.test_map = test_map;
exports.test_filter = test_filter;
exports.test_partition = test_partition;
exports.test_quicksort = test_quicksort;