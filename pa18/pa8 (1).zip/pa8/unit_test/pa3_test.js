/* This file is for testing lazy.js
 * it may help to revisit your initial pa3 submission */

const test_delay = (delay) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_enumFrom = (enumFrom) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_map = (map) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_zipWith = (zipWith) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_tail = (tail) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_cons = (cons) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

exports.test_delay = test_delay;
exports.test_enumFrom = test_enumFrom;
exports.test_map = test_map;
exports.test_zipWith = test_zipWith;
exports.test_tail = test_tail;
exports.test_cons = test_cons;
