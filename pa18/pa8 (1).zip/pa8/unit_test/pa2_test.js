/* This file is for testing helpers.js, require-js.js, lazy.js
 * it may help to revisit your initial pa2 submission           */

const test_for_ = (for_) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

const test_each = (each) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

// test.json exists in the auto-grader folder. You can load this file in for testing
// with loadJSONFile("test.json")
// it has the following structure:
// {
//   "key": 10,
//   "key2": 20
// }
const test_loadJSONFile = (loadJSONFile) => {
  // TODO: Add tests

  // Return false if this implementation is incorrect
  return false;
};

exports.test_for_ = test_for_;
exports.test_each = test_each;
exports.test_loadJSONFile = test_loadJSONFile;
