exports.y = 42;
exports.a = require('../require/a.js');
