module.exports = function (x) {
  return x + 44;
};
