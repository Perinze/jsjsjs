"use strict";

const Ops = {
  Left: "Left",
  Right: "Right",
  Add: "Add",
  Sub: "Sub",
  LBrack: "LBrack",
  RBrack: "RBrack",
  Zero: "Zero",
  Output: "Output",
  Input: "Input",
};

const create_program = (bytes) => {
  // TODO: Copy implementation from step-6
  const prog = [];

  return prog;
};

const optimize_zero = (prog) => {
  // TODO - Implement the optimize_zero function
};

const align_brackets = (prog) => {
  // TODO: Copy implementation from step-6
};

const bf_eval = (prog) => {
  // TODO: Copy implementation from step-6
  // But - add an case for the Zero Op
};

const run = (bytes) => {
  const prog = create_program(bytes);
  optimize_zero(prog);
  align_brackets(prog);
  bf_eval(prog);
};

exports.run = run;
