"use strict";

const Ops = {
  Left: "Left",
  Right: "Right",
  Add: "Add",
  Sub: "Sub",
  LBrack: "LBrack",
  RBrack: "RBrack",
  Output: "Output",
  Input: "Input",
};

const create_program = (bytes) => {
  const prog = [];
  let i = 0;
  while (i < bytes.length) {
    switch (String.fromCharCode(bytes[i])) {
      // TODO: Create program from bytes
      default:
        break;
    }
    i += 1;
  }

  return prog;
};

const align_brackets = (prog) => {
  // TODO: Copy implementation from step-2
};

const bf_eval = (prog, bmap) => {
  // TODO: Copy implementation from step-2
  // But - use prog instead of bytes (ops instead of strings)
};

const run = (bytes) => {
  const prog = create_program(bytes);
  const bmap = align_brackets(prog);
  bf_eval(prog, bmap);
};

exports.run = run;
