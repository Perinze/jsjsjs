"use strict";

const bf_eval = (bytes) => {
  const cells = new Uint8Array(10000);
  let cc = 0;
  let pc = 0;
  while (pc < bytes.length) {
    switch (String.fromCharCode(bytes[pc])) {
      case "<":
        // TODO
        break;
      case ">":
        // TODO
        break;
      case "+":
        // TODO
        break;
      case "-":
        // TODO
        break;
      case "[":
        // TODO
        break;
      case "]":
        // TODO
        break;
      case ".":
        process.stdout.write(String.fromCharCode(cells[cc]));
        break;
      case ",":
        cells[cc] = fs.readSync(
          process.stdin.fd,
          Buffer.alloc(1),
          0,
          1,
          null
        )[0];
        break;
      default:
        break;
    }
    pc += 1;
  }
};

const run = (bytes) => {
  bf_eval(bytes);
};

exports.run = run;
