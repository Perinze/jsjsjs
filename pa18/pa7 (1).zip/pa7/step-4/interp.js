"use strict";

const Ops = {
  Left: "Left",
  Right: "Right",
  Add: "Add",
  Sub: "Sub",
  LBrack: "LBrack",
  RBrack: "RBrack",
  Output: "Output",
  Input: "Input",
};

const create_program = (bytes) => {
  // TODO: Copy implementation from step-3
  // But - The LBrack and RBrack ops should store an operand (infinity to start)
  // That means each OP should be a tuple, [Op, operand?].
  // only the LBrack and RBrack ops should have an operand.
  const prog = [];

  return prog;
};

const align_brackets = (prog) => {
  // TODO: Copy implementation from step-3
  // But - do not return a bmap, instead modify the prog array in place.
  // updating the operands of the corresponding LBrack and RBrack ops.
};

const bf_eval = (prog) => {
  // TODO: Copy implementation from step-3
  // But - use the new operands from the LBrack and RBrack ops instead of bmap.
};

const run = (bytes) => {
  const prog = create_program(bytes);
  align_brackets(prog);
  bf_eval(prog);
};

exports.run = run;
