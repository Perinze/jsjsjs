"use strict";

const Ops = {
  Left: "Left",
  Right: "Right",
  Add: "Add",
  Sub: "Sub",
  LBrack: "LBrack",
  RBrack: "RBrack",
  Output: "Output",
  Input: "Input",
};

const create_program = (bytes) => {
  // TODO: Copy implementation from step-5
  // But - add an operand to the Sub, Left, Right ops.
  // The operand should be the number of consecutive ops of that type.
  const prog = [];

  return prog;
};

const align_brackets = (prog) => {
  // TODO: Copy implementation from step-5
};

const bf_eval = (prog) => {
  // TODO: Copy implementation from step-5
  // But - use the new operands in the Sub, Left, Right ops.
};

const run = (bytes) => {
  const prog = create_program(bytes);
  align_brackets(prog);
  bf_eval(prog);
};

exports.run = run;
