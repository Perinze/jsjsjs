## More repeated codes

Now that we have handled repeated `Add` op codes, let's do the same for
`Sub`, `Left`, and `Right`. The algorithm remains the same.