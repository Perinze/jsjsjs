"use strict";

const align_brackets = (bytes) => {
  const bmap = {};
  let i = 0;
  while (i < bytes.length) {
    switch (String.fromCharCode(bytes[i])) {
      // TODO: (see readme)
      default:
        break;
    }
    i += 1;
  }
  return bmap;
};

const bf_eval = (bytes, bmap) => {
  // TODO: Replace with implementation from step-1
  // But - use the new bmap to speed up the [ and ] operations
};

const run = (bytes) => {
  const bmap = align_brackets(bytes);
  bf_eval(bytes, bmap);
};

exports.run = run;
