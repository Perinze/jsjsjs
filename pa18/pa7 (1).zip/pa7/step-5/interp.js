"use strict";

const Ops = {
  Left: "Left",
  Right: "Right",
  Add: "Add",
  Sub: "Sub",
  LBrack: "LBrack",
  RBrack: "RBrack",
  Output: "Output",
  Input: "Input",
};

const create_program = (bytes) => {
  // TODO: Copy implementation from step-4
  // But - add an operand to the Add op.
  // The operand should be the number of consecutive Add ops.
  const prog = [];

  return prog;
};

const align_brackets = (prog) => {
  // TODO: Copy implementation from step-4
};

const bf_eval = (prog) => {
  // TODO: Copy implementation from step-4
  // But - use the new operands from the Add op.
};

const run = (bytes) => {
  const prog = create_program(bytes);
  align_brackets(prog);
  bf_eval(prog);
};

exports.run = run;
